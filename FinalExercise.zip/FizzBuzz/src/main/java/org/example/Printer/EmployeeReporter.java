package org.example.Printer;

import org.example.Model.Employee;

public interface EmployeeReporter {
    void report(Employee employee);

}
